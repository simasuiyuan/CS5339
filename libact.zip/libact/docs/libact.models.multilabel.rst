libact.models.multilabel package
================================

Submodules
----------

libact.models.multilabel.binary_relevance module
------------------------------------------------

.. automodule:: libact.models.multilabel.binary_relevance
    :members:
    :undoc-members:
    :show-inheritance:

libact.models.multilabel.dummy_clf module
-----------------------------------------

.. automodule:: libact.models.multilabel.dummy_clf
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: libact.models
    :members:
    :undoc-members:
    :show-inheritance:
