libact package
==============

Subpackages
-----------

.. toctree::

    libact.base
    libact.labelers
    libact.models
    libact.query_strategies

Module contents
---------------

.. automodule:: libact
    :members:
    :undoc-members:
    :show-inheritance:
