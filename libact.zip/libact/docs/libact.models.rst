libact.models package
=====================

Submodules
----------

.. toctree::

    libact.models.multilabel

libact.models.sklearn_adapter module
----------------------------------------

.. automodule:: libact.models.sklearn_adapter
    :members:
    :undoc-members:
    :show-inheritance:

libact.models.logistic_regression module
----------------------------------------

.. automodule:: libact.models.logistic_regression
    :members:
    :undoc-members:
    :show-inheritance:

libact.models.perceptron module
-------------------------------

.. automodule:: libact.models.perceptron
    :members:
    :undoc-members:
    :show-inheritance:

libact.models.svm module
-------------------------------

.. automodule:: libact.models.svm
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: libact.models
    :members:
    :undoc-members:
    :show-inheritance:
